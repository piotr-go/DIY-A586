# SD patch for KICK31.ROM MD5:e40a5dfb3d017ba8779faba30cbd1c8e
# by Piotr Gozdur

xdelta3 -d -s KICK31.ROM kick31.delta KICK31SD.ROM
