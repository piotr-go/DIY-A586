# SD patch for KICK314.ROM MD5:61c5b9931555b8937803505db868d5a8
# by Piotr Gozdur

xdelta3 -d -s KICK314.ROM kick314.delta KICK314SD.ROM
