wine uasm32.exe -bin -Fo BIOS_Next186.ROM BIOS_Next186.asm
rm *.err

