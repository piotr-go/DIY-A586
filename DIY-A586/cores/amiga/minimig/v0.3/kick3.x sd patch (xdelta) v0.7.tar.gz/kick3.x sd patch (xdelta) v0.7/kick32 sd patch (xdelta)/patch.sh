# SD patch for KICK32.ROM MD5:1d9b6068abff5a44b4b2f1d5d3516dd9
# by Piotr Gozdur

xdelta patch kick32.patch KICK32.ROM KICK32SD.ROM
