# SD patch for KICK314.ROM MD5:61c5b9931555b8937803505db868d5a8
# by Piotr Gozdur

xdelta patch kick314.patch KICK314.ROM KICK314SD.ROM
