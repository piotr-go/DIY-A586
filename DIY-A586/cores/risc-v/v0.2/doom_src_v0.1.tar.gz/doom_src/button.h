int ps2_get(void);

