#define VGA_D() *(volatile unsigned int *)(0xF0030000)
#define VGA_S() *(volatile unsigned int *)(0xF0030004)
#define VGA_I() *(volatile unsigned int *)(0xF0030008)
#define VGA_C() *(volatile unsigned int *)(0xF003000C)
#define AUDIO_F() *(volatile unsigned int *)(0xF0030010)
#define AUDIO_S() *(volatile unsigned int *)(0xF0030014)
#define AUDIO_L() *(volatile unsigned int *)(0xF0030018)

#define SPI_SD() *(volatile unsigned short *)(0xF0000000)
#define PS2() *(volatile unsigned short *)(0xF0001000)
#define JOY() *(volatile unsigned short *)(0xF0001008)

#define	K_ESC		0x8076
#define	K_F1		0x8005
#define	K_F2		0x8006
#define	K_F3		0x8004
#define	K_F4		0x800c
#define	K_F5		0x8003
#define	K_F6		0x800b
#define	K_F7		0x8083
#define	K_F8		0x800A
#define	K_F9		0x8001
#define	K_F10		0x8009
#define	K_F11		0x8078
#define	K_F12		0x8007
#define	K_INS		0x8170
#define	K_DEL		0x8171
#define	K_HOME		0x816C
#define	K_END		0x8169
#define	K_PUP		0x817D
#define	K_PDOWN		0x817A
#define	K_UP		0x8175
#define	K_DOWN		0x8172
#define	K_LEFT		0x816B
#define	K_RIGHT		0x8174
#define	K_ENTER		0x805A
#define	K_Y		0x8035
#define	K_K		0x8042
#define	K_I		0x8043
#define	K_V		0x802A
#define	K_BAC		0x8066
#define	K_RST		0xEE01

