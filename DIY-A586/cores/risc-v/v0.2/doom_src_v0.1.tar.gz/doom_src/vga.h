#define SCREEN_X 320
#define SCREEN_Y 240

extern void flushDataCache(uint32_t dummy);

extern void *adres_bufora_video;

extern uint16_t VGA_X;
extern uint16_t VGA_Y;
extern uint8_t VGA_C0;
extern uint8_t VGA_C1;

void vga_goto(uint16_t x, uint16_t y, uint8_t c0, uint8_t c1);
void vga_clr(uint8_t color);
void vga_put(char znak);
void vga_print(char *text);
void vga_print_d32(int data, uint8_t cyfry, uint8_t przecinek);
void vga_print_x32(uint32_t data);
void vga_p8x(uint8_t data);
void vga_init(void);

