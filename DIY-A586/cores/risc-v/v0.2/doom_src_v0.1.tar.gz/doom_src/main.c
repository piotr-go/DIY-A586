#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#include <briey.h>

#include "vga.h"
#include "sd.h"
#include "fatfs/ff.h"
#include "config.h"
#include "chocdoom/doom.h"

FATFS fatfs __attribute__ ((aligned(4)));	// File system object
volatile uint32_t systime;

void sleep_ms (uint32_t ms)
{
	uint32_t wait_start;

	wait_start = systime;

	while (systime - wait_start < ms){}
}

int main(){
	interruptCtrl_init(TIMER_INTERRUPT);
	prescaler_init(TIMER_PRESCALER);
	timer_init(TIMER_A);

	TIMER_PRESCALER->LIMIT = 100-1; //1 us rate
	TIMER_A->LIMIT = 1005-1;  //1 ms rate
	TIMER_A->CLEARS_TICKS = 0x00010002;

	TIMER_INTERRUPT->PENDINGS = 0xF;
	TIMER_INTERRUPT->MASKS = 0x1;


	vga_init();

	vga_clr(0x08);
	vga_goto(0, 40, 0x08, 0xFF);
	//vga_print("Hello World...\n");
	//vga_goto(10, 24, 0, 0xFFFF);

	if(sd_reset()){
		vga_print("SD init failed\n");
		flushDataCache(0);
		while(1);
	}

//	if(!f_mount(&fatfs, "", 0)){
//		vga_print("SD mount failed\n");
//		flushDataCache(0);
//		while(1);
//	}
	FRESULT res;
	res = f_mount(&fatfs, "", 0);

	while(1){
		D_DoomMain();
	}
}

#define csr_read(csr)                                           \
({                                                              \
        register unsigned long __v;                             \
        __asm__ __volatile__ ("csrr %0, " #csr : "=r" (__v));                    \
        __v;                                                    \
})

uint16_t KB_data[256];
uint8_t KB_wptr = 0;
uint8_t KB_rptr = 0;

void irqCallback(){
	uint32_t mcause = csr_read(mcause);

	if(mcause == 0x8000000B){
		uint32_t tmp = PS2();

		//vga_goto(10, 100, 0, 0xFF);
		//vga_print("KB: ");
		//vga_print_x32(PS2());

		if((tmp & 0x00008000)){		// KB
			KB_data[KB_wptr] = tmp;
			KB_wptr++;
		}
		if((tmp & 0x80000000)){		// M

		}
	}
	if(mcause == 0x80000007){
		TIMER_INTERRUPT->PENDINGS = 1;
		systime++;
	}
}

