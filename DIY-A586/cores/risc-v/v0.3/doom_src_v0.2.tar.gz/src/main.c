#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>

#include <briey.h>

#include "vga.h"
#include "sd.h"
#include "fatfs/ff.h"
#include "config.h"
#include "chocdoom/doom.h"

FATFS fatfs __attribute__ ((aligned(4)));	// File system object
volatile uint32_t systime;

void sleep_ms (uint32_t ms)
{
	uint32_t wait_start;

	wait_start = systime;

	while (systime - wait_start < ms){}
}

int main(){
	interruptCtrl_init(TIMER_INTERRUPT);
	prescaler_init(TIMER_PRESCALER);
	timer_init(TIMER_A);

	TIMER_PRESCALER->LIMIT = 100-1; //1 us rate
	TIMER_A->LIMIT = 1005-1;  //1 ms rate
	TIMER_A->CLEARS_TICKS = 0x00010002;

	TIMER_INTERRUPT->PENDINGS = 0xF;
	TIMER_INTERRUPT->MASKS = 0x1;


	vga_init();

	vga_clr(0xF7);
	vga_goto(0, 0, 0xF7);

	if(sd_reset()){
		vga_print("SD init failed\n");
		flushDataCache(0);
		while(1);
	}

//	if(!f_mount(&fatfs, "", 0)){
//		vga_print("SD mount failed\n");
//		flushDataCache(0);
//		while(1);
//	}
	FRESULT res;
	res = f_mount(&fatfs, "", 0);

	while(1){
		D_DoomMain();
	}
}

uint16_t KB_data[256];
uint8_t KB_wptr = 0;
uint8_t KB_rptr = 0;

#define csr_read(csr)                                           \
({                                                              \
        register unsigned long __v;                             \
        __asm__ __volatile__ ("csrr %0, " #csr : "=r" (__v));   \
        __v;                                                    \
})

void irqCallback(){
	uint32_t mcause = csr_read(mcause);

	if(mcause == 0x80000007){
		TIMER_INTERRUPT->PENDINGS = 1;
		systime++;
	}
	else if(mcause == 0x8000000B){
		uint32_t tmp;

		tmp = PS2K();
		if((tmp & 0x00008000)){		// KB
			KB_data[KB_wptr] = tmp;
			KB_wptr++;
		}
		tmp = PS2M();
		if((tmp & 0x80000000)){		// M
			static int16_t MX=600, MY=400;
			int16_t t;

			t = ((tmp>>0)&0xFF);
			if((tmp&0x100)) t |= 0xFF00;
			MX += t;

			t = ((tmp>>10)&0xFF);
			if((tmp&0x40000)) t |= 0xFF00;
			MY -= t;

			if(MX < 44) MX = 44;
			if(MY < 32) MY = 32;
			if(MX > 640+44) MX = 640+44;
			if(MY > 480+32) MY = 480+32;

			VGA_MXY() = (MY<<16) | (MX<<0);
		}
	}
}

