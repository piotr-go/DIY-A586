#define VGA_D() *(volatile unsigned int *)(0xF0030000)
#define VGA_S() *(volatile unsigned int *)(0xF0030004)
#define VGA_I() *(volatile unsigned int *)(0xF0030008)
#define VGA_C() *(volatile unsigned int *)(0xF003000C)

#define VGA_TP() *(volatile unsigned int *)(0xF0030010)
#define VGA_TB() *(volatile unsigned int *)(0xF0030014)
#define VGA_FP() *(volatile unsigned int *)(0xF0030018)
#define VGA_FB() *(volatile unsigned int *)(0xF003001C)

#define VGA_MP() *(volatile unsigned int *)(0xF0030020)
#define VGA_MB() *(volatile unsigned int *)(0xF0030024)
#define VGA_MXY() *(volatile unsigned int *)(0xF0030028)

#define AUDIO_P() *(volatile unsigned int *)(0xF0030080)
#define AUDIO_S() *(volatile unsigned int *)(0xF0030084)
#define AUDIO_L() *(volatile unsigned int *)(0xF0030088)
#define AUDIO_F() *(volatile unsigned int *)(0xF003008C)

#define SPI_SD() *(volatile unsigned short *)(0xF0000000)
#define PS2K() *(volatile unsigned int *)(0xF0001000)
#define PS2M() *(volatile unsigned int *)(0xF0001004)
#define JOY() *(volatile unsigned int *)(0xF0001008)

