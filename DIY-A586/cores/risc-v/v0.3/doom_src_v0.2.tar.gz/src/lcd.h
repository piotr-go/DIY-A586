
#define LCD_MAX_X	320
#define LCD_MAX_Y	240

