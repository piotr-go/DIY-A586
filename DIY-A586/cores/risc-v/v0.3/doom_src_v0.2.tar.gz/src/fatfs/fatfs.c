/*
 * fatfs.c
 *
 *  Created on: 20.02.2015
 *      Author: Florian
 */


/*---------------------------------------------------------------------*
 *  include files                                                      *
 *---------------------------------------------------------------------*/

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "diskio.h"
#include "fatfs.h"
#include "ff.h"

/*---------------------------------------------------------------------*
 *  local definitions                                                  *
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*
 *  external declarations                                              *
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*
 *  public data                                                        *
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*
 *  private data                                                       *
 *---------------------------------------------------------------------*/

static FATFS fso;

/*---------------------------------------------------------------------*
 *  private functions                                                  *
 *---------------------------------------------------------------------*/

/*
 * Returns the volume name for media type as a string
 *
 * @param	dev	media device
 * @return	volume name
 */
static char* fatfs_get_vol (diskio_media_t dev)
{
	switch (dev)
	{
		case DISK_USB:
			return "0:";

		case DISK_SDCARD:
			return "1:";

		default:
			return "";
	}
}

/*---------------------------------------------------------------------*
 *  public functions                                                   *
 *---------------------------------------------------------------------*/

/*
 * Initialization
 */
void fatfs_init (void)
{

}

/*
 * Check if media exists
 *
 * @param	dev	media device
 * @return	true on success, otherwise false
 */
bool fatfs_check_media (diskio_media_t dev)
{
	return true;
}

/*
 * Mount media device
 *
 * @param	dev	media device
 * @return	true on success, otherwise false
 */
bool fatfs_mount (diskio_media_t dev)
{
	DWORD free_clusters;
	FATFS* fs;
	char* volume;

	if ((f_mount (&fso, "0:", 0) == FR_OK) )
	{
		return true;
	}

	return false;
}

/*
 * Unmount media device
 *
 * @param	dev	media device
 * @return	true on success, otherwise false
 */
bool fatfs_unmount (diskio_media_t dev)
{
	if (f_mount (NULL, "0:", 1) == FR_OK)
	{
		return true;
	}

	return false;
}

/*---------------------------------------------------------------------*
 *  eof                                                                *
 *---------------------------------------------------------------------*/
