typedef enum
{
	TOUCH_PRESSED,
	TOUCH_RELEASED
} touch_status_t;

typedef struct
{
	touch_status_t	status;
	uint16_t		x;
	uint16_t		y;
} touch_state_t;

