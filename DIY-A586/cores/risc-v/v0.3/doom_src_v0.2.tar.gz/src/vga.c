#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "config.h"
#include "vga.h"

void *adres_bufora_video;

#define RES_X 320
#define RES_Y 240

__attribute__ ((aligned (4*8))) short audioBuffer[2304*8];
__attribute__ ((aligned (4*8))) uint8_t vgaFramebuffer[RES_Y][RES_X];


uint8_t VGA_X = 0;
uint8_t VGA_Y = 0;
uint8_t VGA_C0 = 0x0;
uint8_t VGA_C1 = 0xF;

void vga_goto(uint8_t x, uint8_t y, uint8_t c){
	VGA_X = x;
	VGA_Y = y;
	VGA_C0 = c >> 4;
	VGA_C1 = c & 0x0F;
}

void vga_clr(uint8_t color){
	uint32_t x;

	VGA_TP() = 0;
	for(x=0; x<80*40; x++) VGA_TB() = 0x0020 | (color<<8);

	VGA_X = 0;
	VGA_Y = 0;
	//VGA_C0 = 0x0000;
	//VGA_C1 = 0xFFFF;
}

void vga_put(char znak){
	if(znak == '\n'){
		VGA_X = 0;
		VGA_Y++;
		if(VGA_Y>=40) VGA_Y = 0;
		return;
	}

	VGA_TP() = (VGA_Y * 80) + (VGA_X);
	VGA_TB() = ((VGA_C0 & 0x0F)<<12) | ((VGA_C1 & 0x0F)<<8) | (znak & 0xFF);

	VGA_X++;
	if(VGA_X>=80){
		VGA_X = 0;
		VGA_Y++;
		if(VGA_Y>=40) VGA_Y = 0;
	}
}

void vga_print(char *text){
	while(*text != 0) vga_put(*text++);
}

void vga_print_d32(int data, uint8_t cyfry, uint8_t przecinek){
	char text[13];
	int i=12;
	int neg = data;

	text[i] = 0;

	while(przecinek){
		text[--i] = data%10 + 0x30;
		data /= 10;

		if(--przecinek == 0) text[--i] = '.';
	}

	if(data){
		while(data != 0){
			text[--i] = data%10 + 0x30;
			data /= 10;

			if(cyfry > 0) cyfry--;
		}
	}
	else{
		text[--i] = '0';
		if(cyfry > 0) cyfry--;
	}

	if(neg < 0){
		text[--i] = '-';
		if(cyfry > 0) cyfry--;
	}

	while(cyfry){
		cyfry--;
		text[--i] = ' ';
	}

	vga_print(&text[i]);
}

void vga_init(void){
	uint32_t x;

	memset(vgaFramebuffer, 0, sizeof(vgaFramebuffer));
	memset(audioBuffer, 0, sizeof(audioBuffer));

	AUDIO_F() = 2278; //44100
	AUDIO_S() = (uint32_t)audioBuffer;
	AUDIO_L() = 0;

	VGA_S() = (uint32_t)vgaFramebuffer;
	adres_bufora_video = vgaFramebuffer;

	VGA_TP() = 0;
	for(x=0; x<80*40; x++) VGA_TB() = 0x0020;

	//VGA_MXY() = (400<<16) | (600<<0);

	VGA_D() = 0x0D;
}

