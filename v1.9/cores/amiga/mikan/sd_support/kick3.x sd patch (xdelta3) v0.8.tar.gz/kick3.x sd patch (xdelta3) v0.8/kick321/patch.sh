# SD patch for KICK321.ROM MD5:c6b6010db581ad9f77a89622d6d9cd29
# by Piotr Gozdur

xdelta3 -d -s KICK321.ROM kick321.delta KICK321SD.ROM
